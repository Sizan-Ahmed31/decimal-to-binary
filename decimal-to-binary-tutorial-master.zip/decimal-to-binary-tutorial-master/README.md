# Decimal to Binary Converter

[Decimal to Binary converter][1] is a part of the Series [_Vanilla JavaScript Project in Bangla_][2] by [JS Bangladesh][3]

[1]: https://youtu.be/4Rzm3BE6DL0 'Decimal to Binary Converter'
[2]: https://www.youtube.com/watch?v=4Rzm3BE6DL0&list=PL4iFnndHldujaLgJcoO8d4yUlAKBM55GC&ab_channel=JSBangladesh 'Full Playlist'
[3]: https://jsbangladesh.com 'Official Website'

## Project Screenshot

<img src="./screenshot.jpg">
